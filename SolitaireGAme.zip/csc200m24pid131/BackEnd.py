import pygame
import random
suits = ["Heart", "Diamond", "Club", "Spade"]
ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
class PlayingCard:
    def __init__(self, suits, ranks,faceUp=False):
        self.ranks = ranks
        self.suits = suits
        self.faceUp = faceUp
        self.image = self.Loadimage()
        self.backimage = self.LoadBackimage()
        self.color = 'red' if self.suits in ['Heart', 'Diamond'] else 'black'
    def Flip(self):
        if self.faceUp:
            return
        self.faceUp = True
    def Loadimage(self):
        imagePath=f"Pictures/{self.suits}{self.ranks}.png"
        image=pygame.image.load(imagePath)
        resized=pygame.transform.scale(image, (100, 150))
        resized=AddBorder(resized)
        return resized
    def LoadBackimage(self):
        imagePath=f"Pictures/CardsBack1.png"
        image=pygame.image.load(imagePath)
        resized=pygame.transform.scale(image, (100, 160))
        resized=AddBorder(resized)
        return resized
    def Display(self):
        if self.faceUp:
            return f"{self.ranks} of {self.suits}"
        else:
            return "Face down"
    def Displayimage(self):
        return self.image
    def DisplayCard(self, card, screen, position):
        if card.faceUp:
            screen.blit(card.image, position)
        else:
            screen.blit(card.backimage, position)

class DeckOfCards:
    def __init__(self):
        self.cards = []
        self.InitializeDeck()
        self.Shuffle()
    def InitializeDeck(self):
        for suit in suits:
            for rank in ranks:
                self.cards.append(PlayingCard(suit, rank))
    def Shuffle(self):
        return random.shuffle(self.cards)
    def Deal(self):
        return self.cards.pop()
    def RemainingCards(self):
        return len(self.cards)
class Foundation:
    def __init__(self, suit):
        self.suit = suit
        self.cards = [] 
        self.rank_order = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
    def AddCard(self, card):
        if self.CanAddCard(card):
            self.cards.append(card)
            return True
        return False
    def MoveCard(self, fromColIndex, card, Piles):
        if fromColIndex is None:
            return False
        fromPile = Piles[fromColIndex]
        if fromPile.top()!=card:
            return False, Piles
        if card and card.faceUp and self.CanAddCard(card):
            cradsToMove = fromPile.RemoveFrom(card)
            if cradsToMove.Head:
                newTopCard = fromPile.top()
                if fromPile is None:
                    fromPile.Head=None
                if newTopCard and not newTopCard.faceUp:
                    newTopCard.Flip()
                self.AddCard(card)
                return True, Piles
        return False, Piles
    def CanAddCard(self, card):
        if not self.cards:
            return card.suits == self.suit and card.ranks == 'A'
        expectedRank = self.rank_order[len(self.cards)]
        return card.suits == self.suit and card.ranks == expectedRank
    def IsComplete(self):
        return len(self.cards) == 13
    
    def __repr__(self):
        return f"Foundation({self.suit}): {self.cards}"
    def DisplaySingleFoundation(self,screen, foundation, foundationPosition):
        foundationX, foundationY = foundationPosition
        if foundation.cards:
            topCard = foundation.cards[-1]
            cardimage = topCard.image
            screen.blit(cardimage, (foundationX, foundationY))

class Node:
    def __init__(self, Data):
        self.Data = Data
        self.Next = None
class Stack:
    def __init__(self):
        self.Head = None
    def IsEmpty(self):
        return self.Head is None
    def MakeStackEmpty(self):
        self.Head=None
        return
    def LengthOfStack(self, pile):
        temp=pile.Head
        if temp==None:
            return 0
        i=0
        while temp.Next is not None:
            temp=temp.Next
            i+=1
        return i
    def Push(self, Data):
        newNode = Node(Data)
        if self.Head is None:
            self.Head=newNode
            return
        temp=self.Head
        while temp.Next is not None:
            temp=temp.Next
        temp.Next=newNode
    def top(self):
        if self.IsEmpty():
            return None
        temp=self.Head
        while temp.Next is not None:
            temp=temp.Next
        return temp.Data
    def DisplayStack(self):
        current = self.Head
        while current:
            print(current.Data.Display())
            current = current.Next
    def Size(self):
        count = 0
        current = self.Head
        while current:
            current = current.Next
            count += 1
        return count
    def GetLast(self):
        if self.IsEmpty():
            return None  
        current = self.Head
        while current.Next:  
            current = current.Next
        return current.Data 
    def CutOffAt(self, node):
        if not node:
            return  
        current = self.Head
        if self.Head.Data==node.Data:
            self.Head=None
        while current and current.Next != node:
            current = current.Next
        if current and current.Next == node:
            current.Next = None
    def RemoveFrom(self, card):
        current = self.Head
        removed_stack = Stack()
        while current and current.Data != card:
            current = current.Next
        if current:
            removed_stack.Head = current 
            self.CutOffAt(current)
        return removed_stack
    def PushStack(self, otherStack):
        if not otherStack.Head:
            return  
        if not self.Head:
            self.Head = otherStack.Head
        else:
            current = self.Head
            while current.Next:
                current = current.Next
            current.Next = otherStack.Head

class Stockpile:
    def __init__(self, deck):
        self.Cards = deck.cards[:]
        self.DrawnCards = []
        self.CurrentDrawIndex = 0
    def DrawOneCard(self):
        if not self.Cards and self.DrawnCards:
            self.RecycleDrawnCards()
        if self.Cards:
            DrawnCard = self.Cards.pop(0)
            DrawnCard.Flip()
            self.DrawnCards.append(DrawnCard)
            self.CurrentDrawIndex = len(self.DrawnCards) - 1
            return DrawnCard
        elif self.DrawnCards:
            self.CurrentDrawIndex = (self.CurrentDrawIndex + 1) % len(self.DrawnCards)
            return self.DrawnCards[self.CurrentDrawIndex]
        return None
    def RecycleDrawnCards(self):
        self.Cards = self.DrawnCards[:]
        self.DrawnCards = []
        self.CurrentDrawIndex = 0
    def MoveCardToTableau(self, tableau, pile_index):
        if not self.DrawnCards:
            return False

        CardToMove = self.DrawnCards[self.CurrentDrawIndex]
        if tableau.CanAddCard(pile_index, CardToMove):
            self.DrawnCards.pop(self.CurrentDrawIndex)
            tableau.piles[pile_index].push(CardToMove)
            return True
        return False
    def PrintStockPile(self, screen, stockPile):
        font = pygame.font.SysFont(None, 16) 
        Pile=['StockPile', 'WastePile']
        for i, suit in enumerate(Pile):
            if len(stockPile.Cards)>0 and i==0:
                screen.blit(stockPile.Cards[0].backimage, ((300+i*130), 40))
                continue
            if len(stockPile.DrawnCards)>0 and i==1:
                screen.blit(stockPile.DrawnCards[-1].image, ((300+i*130), 40))
                continue
            pygame.draw.rect(screen, (0, 0, 0), ((300 + i * 130), 40, 100, 160), 2)
    def DetectStockPileClick(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouseX, mouseY = event.pos
            shockPileRect = pygame.Rect(300, 40, 100, 150)
            wastePileRect = pygame.Rect(430, 40, 100, 150)
            if shockPileRect.collidepoint(mouseX, mouseY):
                return "StockPile"
            if wastePileRect.collidepoint(mouseX, mouseY):
                return "WastePile"
        return None
    def GetTopCardFromWastepileClick(self, event, stockpile):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            cllickedArea = stockpile.DetectStockPileClick(event)
            if cllickedArea == "WastePile" and stockpile.DrawnCards:
                return stockpile.DrawnCards[-1]
        return None
    def StartDrag(self, event, stockpile):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            cllickedArea = stockpile.DetectStockPileClick(event)
            if cllickedArea == "WastePile" and stockpile.DrawnCards:
                return stockpile.DrawnCards[-1]
        return None
    def DragCard(self, screen, card, mouseX, mouseY):
        if card:
            screen.blit(card.image, (mouseX - card.image.get_width() // 2, mouseY - card.image.get_height() // 2))
    def PlaceCard(self, event, draggedCard, tableau, foundations, foundationPositions):
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            mouseX, mouseY = event.pos
            card_width = draggedCard.image.get_width()
            card_height = draggedCard.image.get_height()
            for i, pile in enumerate(tableau.Piles):
                x, y = tableau.columnPosition[i]
                pile_rect = pygame.Rect(x, y, card_width, card_height)
                
                pile_rect.height = max(card_height, 500)
                if pile_rect.collidepoint(mouseX, mouseY) and tableau.CanAddCard(pile, draggedCard):
                    draggedCard.faceUp=True
                    pile.Push(draggedCard)
                    self.DrawnCards.pop()
                    return True
            for i, foundation in enumerate(foundations):
                foundationX, foundationY = foundationPositions[i]
                pile_rect = pygame.Rect(foundationX, foundationY, card_width, card_height)

                if pile_rect.collidepoint(mouseX, mouseY) and foundation.CanAddCard(draggedCard):
                    foundation.AddCard(draggedCard)
                    self.DrawnCards.pop()
                    return True

        return False

class Tableau:
    def __init__(self, columnPosition):
        self.Piles = [Stack() for _ in range(7)]
        self.columnPosition = columnPosition
    def InitializeTableau(self, deck):
        for i in range(7): 
            for j in range(i + 1):
                card = deck.Deal()
                if card is None:
                    raise ValueError("Deck ran out of cards")
                if j == i:
                    card.Flip()
                self.Piles[i].Push(card)
        return deck
    def CanAddCard(self, toPile, CardToAdd):
        if toPile.Head is None and CardToAdd.ranks=='K':
            return True
        if not CardToAdd:
            return False
        if not toPile:
            return CardToAdd.ranks=='K'
        topCard = toPile.top()
        if not topCard:
            return False
        topCard = toPile.top()  
        oppositeColor = CardToAdd.color != topCard.color
        ranksOrder = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        cardToMoveIndex = ranksOrder.index(CardToAdd.ranks)
        topCardIndex = ranksOrder.index(topCard.ranks)
        correct_rank = (cardToMoveIndex + 1 == topCardIndex)
        return oppositeColor and correct_rank
    def DisplayTableau(self):
        for i, pile in enumerate(self.Piles):
            print(f"Pile {i + 1}:")
            pile.DisplayStack()
    def GetTopCard(self, PileIndex):
        return self.Piles[PileIndex].top()
    def MoveCardToFoundation(self, FromPileIndex, foundation):
        FromPile = self.Piles[FromPileIndex]
        CardToMove = FromPile.top()
        if CardToMove and foundation.AddCard(CardToMove):
            FromPile.Pop()
            NewTopCard = FromPile.top()
            if NewTopCard and not NewTopCard.faceUp:
                NewTopCard.Flip()
            return True
        return False
    def RenderTableau(self, screen):
        for colIndex in range(len(self.Piles)):
            pile = self.Piles[colIndex]
            current = pile.Head 
            x, y = self.columnPosition[colIndex] 
            y_offset = 30
            if pile.LengthOfStack(pile)>10:
                i=15
            i = 0
            while current:
                card = current.Data  
                card_y = y + i * y_offset 
                card.DisplayCard(card, screen, (x, card_y))
                current = current.Next
                i += 1
    def DetectCardClick(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  
            mouseX, mouseY = event.pos
            for colIndex, pile in enumerate(self.Piles):
                current = pile.Head
                i = 0
                x, y = self.columnPosition[colIndex]
                y_offset = 30
                while current:
                    card = current.Data
                    card_rect = pygame.Rect(x, y + i * y_offset, card.image.get_width(), card.image.get_height())
                    if card.faceUp and card_rect.collidepoint(mouseX, mouseY):  
                        return colIndex, card 
                    current = current.Next
                    i += 1
        return None, None
    def MoveCard(self, fromColIndex, toColIndex, card):
        if fromColIndex is None or toColIndex is None:
            return False
        fromPile = self.Piles[fromColIndex]
        toPile = self.Piles[toColIndex]
        if card and card.faceUp and self.CanAddCard(toPile, card):
            cradsToMove = fromPile.RemoveFrom(card)
            if not fromPile.IsEmpty():
                fromPile.top().Flip()
            if self.CanAddCard(toPile, card) and toPile.Head is None:
                toPile.PushStack(cradsToMove)
                return True
            if cradsToMove.Head:
                toPile.PushStack(cradsToMove)
                newTopCard = fromPile.top()
                if fromPile is None:
                    fromPile.Head=None
                if newTopCard and not newTopCard.faceUp:
                    newTopCard.Flip()
                if toPile.top() and not toPile.top().faceUp:
                    toPile.top().Flip()
                return True
        return False

def CreateRoundedimage(image, radius):
    roundedimage = pygame.Surface(image.getSize(), pygame.SRCALPHA)
    roundedimage = roundedimage.convertAlpha()
    pygame.draw.rect(roundedimage, (255, 255, 255, 0), (0, 0, *image.getSize()))
    rect = pygame.Rect(0, 0, *image.getSize())
    pygame.draw.rect(roundedimage, (255, 255, 255), rect, borderRadius=radius)
    mask = pygame.mask.fromSurface(roundedimage)
    for x in range(rect.width):
        for y in range(rect.height):
            if mask.getAt((x, y)):
                roundedimage.setAt((x, y), image.getAt((x, y)))
    return roundedimage

def AddBorder(image, borderThickness=2, radius=8):
    width, height = image.get_width(), image.get_height()
    newSurface = pygame.Surface((width + 2 * borderThickness, height + 2 * borderThickness), pygame.SRCALPHA)
    borderColor = (250, 0, 0)
    
    # Use border_radius instead of borderRadius
    pygame.draw.rect(newSurface, borderColor, (0, 0, width + 2 * borderThickness, height + 2 * borderThickness), border_radius=radius)
    pygame.draw.rect(newSurface, (0, 0, 0, 0), (borderThickness, borderThickness, width, height))
    newSurface.blit(image, (borderThickness, borderThickness))
    
    return newSurface
