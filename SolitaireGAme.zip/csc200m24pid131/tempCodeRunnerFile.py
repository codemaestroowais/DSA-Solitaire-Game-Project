import pygame
import sys
import os
import time
from BackEnd import *
os.environ['SDL_VIDEO_CENTERED'] = '1'
def PrintFoundation(foundations):
    foundation_images = {
        "Heart": pygame.image.load('Pictures/Heart.png'),
        "Diamond": pygame.image.load('Pictures/Diamond.png'),
        "Club": pygame.image.load('Pictures/Club.png'),
        "Spade": pygame.image.load('Pictures/Spade.png')
    }
    for key in foundation_images:
        foundation_images[key] = pygame.transform.scale(foundation_images[key], (100, 160))
    suits = ["Heart", "Diamond", "Club", "Spade"]
    for i, suit in enumerate(suits):
        if len(foundations[i].cards) > 0:
            continue
        screen.blit(foundation_images[suit], foundationPosition[i])
        pygame.draw.rect(screen, (0, 0, 0), (*foundationPosition[i], 100, 160), 2)
def CheckWin(foundations):
    for foundation in foundations:
        if foundation.IsComplete() is False:
            return False
    return True     
foundationPosition = [((690 + i * 130), 40) for i in range(4)]
pygame.init()
foundations = [Foundation(suit) for suit in ['Heart', 'Diamond', 'Club', 'Spade']]
width, height = 1500, 750
widthmain, heightmain = 1429, 810
widthHelp, heightHelp = 1418, 1080
widthWon, heightWon = 623, 341
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption('Solitaire Game')
pygame.mixer.music.load("Pictures/Sound.mp3")
pygame.mixer.music.set_volume(1.0)
pygame.mixer.music.play(-1)
columnPositions = [(300 + i * 130, 250) for i in range(7)]
deck = DeckOfCards()
tableau = Tableau(columnPositions)
tableau.InitializeTableau(deck)
stockPiles = Stockpile(deck)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
font = pygame.font.Font("Pictures/SourGummy-VariableFont_wdth,wght.ttf", 30)
clock = pygame.time.Clock()
startTime = time.time() 
moveCount = 0
score = 0
FPS = 120
def UpdateScore(val):
    global score
    score += val
def DisplayScore():
    font1 = pygame.font.Font("Pictures/static/EduAUVICWANTPre-Bold.ttf", 30)
    scoreText = f"Score: {score}"
    textSurface = font1.render(scoreText, True, (255, 255, 255))
    screen.blit(textSurface, (30, 170)) 
def DrawRoundedRect(surface, color, rect, radius):
    roundedRectSurface = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(roundedRectSurface, color, (0, 0, rect.width, rect.height), border_radius=radius)
    surface.blit(roundedRectSurface, rect.topleft)
def DrawButtonWithBorder(surface, color, borderColor, rect, radius):
    DrawRoundedRect(surface, color, rect, radius)
    pygame.draw.rect(surface, borderColor, rect, width=2, border_radius=radius)
def DisplayStat():
    elapsed_time = int(time.time() - startTime)
    minutes = elapsed_time // 60
    seconds = elapsed_time % 60
    time_text = f"Time:  {minutes:02}:{seconds:02}"
    font1 = pygame.font.Font("Pictures/static/EduAUVICWANTPre-Bold.ttf", 30)
    time_surface = font1.render(time_text, True, (255, 255, 255))
    moves_surface = font1.render(f"Moves:  {moveCount}", True, (255, 255, 255))
    screen.blit(time_surface, (30, 70))
    screen.blit(moves_surface, (30, 120))
def MakeMove(val):
    global moveCount
    moveCount += val
class Button:
    def __init__(self, x, y, width, height, color, text, action=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color
        self.text = text
        self.action = action

    def draw(self, screen):
        DrawButtonWithBorder(screen, self.color, WHITE, self.rect, radius=10)
        textSurface = font.render(self.text, True, WHITE)
        screen.blit(textSurface, (self.rect.x + (self.rect.width - textSurface.get_width()) // 2,
                                   self.rect.y + (self.rect.height - textSurface.get_height()) // 2))
    def IsClicked(self, mousePos):
        return self.rect.collidepoint(mousePos)
def ButtonAction1():
    StartGame()
def ButtonAction2():
    helpPage()
def ButtonAction3():
    global running
    print("Game is Exited")
    running = False
def ButtonAction4():
    MainPage()
def ButtonAction5():
    MainPage()
def MainPage():
    global running
    screen = pygame.display.set_mode((widthmain, heightmain))
    background_image = pygame.image.load('Pictures/MainScreen.png')
    background_image=pygame.transform.scale(background_image, (1450, 750))
    button1 = Button(570, 260, 225, 50, BLACK, "Start Playing", ButtonAction1)
    button2 = Button(570, 330, 225, 50, BLACK, "Help", ButtonAction2)
    button3 = Button(570, 400, 225, 50, BLACK, "Exit Game", ButtonAction3)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN: 
                mousePos = event.pos
                if button1.IsClicked(mousePos):
                    button1.action() 
                elif button2.IsClicked(mousePos):
                    button2.action()
                elif button3.IsClicked(mousePos):
                    button3.action()  
        screen.blit(background_image, (0, 0))
        button1.draw(screen)
        button2.draw(screen)
        button3.draw(screen)
        pygame.display.update()
def StartGame():
    global running
    screen = pygame.display.set_mode((width, height))
    background_image = pygame.image.load('Pictures/Background.jpg')
    background_image=pygame.transform.scale(background_image, (width, height))
    selectedColIndex = None
    selectedCard = None
    dragging = False
    running = True
    button5 = Button(630, 680, 210, 50, RED, "Back", ButtonAction5)
    labelText = "Hello, Pygame!"
    label_surface = font.render(labelText, True, BLACK) 
    draggedCard = None
    while running:
        fps_text = font.render(f"FPS: {int(clock.get_fps())}", True, BLACK)
        screen.blit(fps_text, (10, 10))
        screen.blit(background_image, (0, 0))
        stockPiles.PrintStockPile(screen, stockPiles)
        PrintFoundation(foundations)
        for i in range(4):
            foundations[i].DisplaySingleFoundation(screen, foundations[i], foundationPosition[i])
        tableau.RenderTableau(screen)
        button5.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if stockPiles.DetectStockPileClick(event) == "StockPile":
                    stockPiles.DrawOneCard()
                else:
                    draggedCard = stockPiles.StartDrag(event, stockPiles)
                selectedColIndex, selectedCard = tableau.DetectCardClick(event)
                if selectedCard and selectedCard.faceUp:
                    dragging = True
                mousePos = event.pos
                if button5.IsClicked(mousePos):
                    button5.action() 
            elif event.type == pygame.MOUSEBUTTONUP:
                if dragging and selectedCard:
                    mouseX, mouseY = event.pos
                    valid_move = False
                    for col_index in range(len(tableau.Piles)):
                        x, y = tableau.columnPosition[col_index]
                        pile_rect = pygame.Rect(x, y, 100, 500)
                        if pile_rect.collidepoint(mouseX, mouseY):
                            valid_move = tableau.MoveCard(selectedColIndex, col_index, selectedCard)
                            if valid_move:
                                print(f"Moved card from pile {selectedColIndex} to pile {col_index}")
                                UpdateScore(1)
                                MakeMove(1)
                                break
                    for col_index in range(len(foundations)):
                        x, y = foundationPosition[col_index]
                        pile_rect = pygame.Rect(x, y, 100, 500)
                        if pile_rect.collidepoint(mouseX, mouseY):
                            (valid_move, tableau.Piles) = foundations[col_index].MoveCard(selectedColIndex, selectedCard, tableau.Piles)
                            if valid_move:
                                print(f"Moved card from pile {selectedColIndex} to foundation {col_index}")
                                UpdateScore(1)
                                MakeMove(1)
                                break
                    dragging = False
                    selectedColIndex = None
                    selectedCard = None

                elif draggedCard:
                    if stockPiles.PlaceCard(event, draggedCard, tableau, foundations, foundationPosition):
                        print("Moved card from waste pile to a valid location.")
                        UpdateScore(1)
                        MakeMove(1)
                    draggedCard = None
        if dragging and selectedCard:
            mouseX, mouseY = pygame.mouse.get_pos()
            if selectedCard.faceUp:
                screen.blit(selectedCard.image, (mouseX - selectedCard.image.get_width() // 2, mouseY - selectedCard.image.get_height() // 2))
        elif draggedCard:
            mouseX, mouseY = pygame.mouse.get_pos()
            stockPiles.DragCard(screen, draggedCard, mouseX, mouseY)
        if CheckWin(foundations):
            running = False
            WonGame()
            
        DisplayStat()
        DisplayScore()
        pygame.display.flip()
def helpPage():
    global running
    screen = pygame.display.set_mode((widthHelp, heightHelp))
    background_image = pygame.image.load('Pictures/Rules.png')
    background_image=pygame.transform.scale(background_image, (1000, 550))
    button4 = Button(600, 700, 210, 50, BLACK, "Back", ButtonAction4)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousePos = event.pos
                if button4.IsClicked(mousePos):
                    button4.action()
        screen.blit(background_image, (230, 150))
        button4.draw(screen)
        pygame.display.update()
def WonGame():
    global running
    screen = pygame.display.set_mode((widthWon, heightWon))
    frames = []
    frame_count = 2
    for i in range(frame_count):
        frame = pygame.image.load(f"Pictures/YOUWon{i}.png")
        frames.append(frame)
    clock = pygame.time.Clock()
    frame_index = 0
    frame_delay = 100
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.blit(frames[frame_index], (0, 0))
        pygame.display.flip()
        frame_index = (frame_index + 1) % frame_count
        pygame.time.delay(frame_delay)

if __name__ == "__main__":
    MainPage()
pygame.quit()
sys.exit()

